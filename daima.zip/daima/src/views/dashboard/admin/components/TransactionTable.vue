<template>
  <el-card class="box-card">
  <div>
    <a href="https://github.com/PanJiaChen/vue-element-admin/blob/master/README.zh-CN.md">源码地址</a>
  </div>
 </el-card>
</template>

<style>
  .text {
    font-size: 14px;
  }

  .item {
    margin-bottom: 18px;
  }

  .clearfix:before,
  .clearfix:after {
    display: table;
    content: "";
  }
  .clearfix:after {
    clear: both
  }

  .box-card {
    width: 800px;
  }
</style>
